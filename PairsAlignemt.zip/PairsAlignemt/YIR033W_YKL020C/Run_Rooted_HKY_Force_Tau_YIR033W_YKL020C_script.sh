#!/bin/bash
cd YIR033W_YKL020C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python Rooted_HKY_Force_Tau_YIR033W_YKL020C.py > Rooted_HKY_Force_Tau_YIR033W_YKL020C_PrintScreen.txt