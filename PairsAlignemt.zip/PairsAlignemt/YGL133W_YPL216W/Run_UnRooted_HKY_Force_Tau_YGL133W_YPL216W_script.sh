#!/bin/bash
cd YGL133W_YPL216W
/Library/Frameworks/Python.framework/Versions/7.3/bin/python UnRooted_HKY_Force_Tau_YGL133W_YPL216W.py > UnRooted_HKY_Force_Tau_YGL133W_YPL216W_PrintScreen.txt