#!/bin/bash
cd YDR518W_YCL043C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python UnRooted_HKY_Force_Tau_YDR518W_YCL043C.py > UnRooted_HKY_Force_Tau_YDR518W_YCL043C_PrintScreen.txt