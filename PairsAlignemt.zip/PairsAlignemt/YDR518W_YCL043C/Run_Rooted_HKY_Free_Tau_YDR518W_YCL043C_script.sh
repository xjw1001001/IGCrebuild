#!/bin/bash
cd YDR518W_YCL043C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python Rooted_HKY_Free_Tau_YDR518W_YCL043C.py > Rooted_HKY_Free_Tau_YDR518W_YCL043C_PrintScreen.txt