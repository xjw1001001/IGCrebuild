#!/bin/bash
cd YER102W_YBL072C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python Rooted_HKY_Free_Tau_YER102W_YBL072C.py > Rooted_HKY_Free_Tau_YER102W_YBL072C_PrintScreen.txt