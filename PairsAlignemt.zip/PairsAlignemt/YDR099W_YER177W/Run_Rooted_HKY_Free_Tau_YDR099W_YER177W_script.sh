#!/bin/bash
cd YDR099W_YER177W
/Library/Frameworks/Python.framework/Versions/7.3/bin/python Rooted_HKY_Free_Tau_YDR099W_YER177W.py > Rooted_HKY_Free_Tau_YDR099W_YER177W_PrintScreen.txt