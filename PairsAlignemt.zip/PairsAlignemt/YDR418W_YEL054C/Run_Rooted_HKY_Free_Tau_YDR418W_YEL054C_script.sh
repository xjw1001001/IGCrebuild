#!/bin/bash
cd YDR418W_YEL054C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python Rooted_HKY_Free_Tau_YDR418W_YEL054C.py > Rooted_HKY_Free_Tau_YDR418W_YEL054C_PrintScreen.txt