#!/bin/bash
cd YER131W_YGL189C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python UnRooted_HKY_Free_Tau_YER131W_YGL189C.py > UnRooted_HKY_Free_Tau_YER131W_YGL189C_PrintScreen.txt