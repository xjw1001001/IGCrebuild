#!/bin/bash
cd YER131W_YGL189C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python Rooted_HKY_Force_Tau_YER131W_YGL189C.py > Rooted_HKY_Force_Tau_YER131W_YGL189C_PrintScreen.txt