#!/bin/bash
cd YBR191W_YPL079W
/Library/Frameworks/Python.framework/Versions/7.3/bin/python Rooted_HKY_Force_Tau_YBR191W_YPL079W.py > Rooted_HKY_Force_Tau_YBR191W_YPL079W_PrintScreen.txt