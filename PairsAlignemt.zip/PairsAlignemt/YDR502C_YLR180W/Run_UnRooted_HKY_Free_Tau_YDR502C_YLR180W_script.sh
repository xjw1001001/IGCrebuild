#!/bin/bash
cd YDR502C_YLR180W
/Library/Frameworks/Python.framework/Versions/7.3/bin/python UnRooted_HKY_Free_Tau_YDR502C_YLR180W.py > UnRooted_HKY_Free_Tau_YDR502C_YLR180W_PrintScreen.txt