#!/bin/bash
cd YBR117C_YPR074C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python Rooted_HKY_Free_Tau_YBR117C_YPR074C.py > Rooted_HKY_Free_Tau_YBR117C_YPR074C_PrintScreen.txt