#!/bin/bash
cd YBR117C_YPR074C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python UnRooted_HKY_Force_Tau_YBR117C_YPR074C.py > UnRooted_HKY_Force_Tau_YBR117C_YPR074C_PrintScreen.txt