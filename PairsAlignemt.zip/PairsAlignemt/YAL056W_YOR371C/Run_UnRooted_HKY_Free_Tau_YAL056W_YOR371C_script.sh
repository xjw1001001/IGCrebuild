#!/bin/bash
cd YAL056W_YOR371C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python UnRooted_HKY_Free_Tau_YAL056W_YOR371C.py > UnRooted_HKY_Free_Tau_YAL056W_YOR371C_PrintScreen.txt