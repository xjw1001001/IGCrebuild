#!/bin/bash
cd YER074W_YIL069C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python Rooted_HKY_Free_Tau_YER074W_YIL069C.py > Rooted_HKY_Free_Tau_YER074W_YIL069C_PrintScreen.txt