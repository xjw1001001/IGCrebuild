#!/bin/bash
cd YBR024W_YBR037C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python UnRooted_HKY_Force_Tau_YBR024W_YBR037C.py > UnRooted_HKY_Force_Tau_YBR024W_YBR037C_PrintScreen.txt