#!/bin/bash
cd YDR438W_YML018C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python UnRooted_HKY_Force_Tau_YDR438W_YML018C.py > UnRooted_HKY_Force_Tau_YDR438W_YML018C_PrintScreen.txt