#!/bin/bash
cd YHR106W_YDR353W
/Library/Frameworks/Python.framework/Versions/7.3/bin/python UnRooted_HKY_Free_Tau_YHR106W_YDR353W.py > UnRooted_HKY_Free_Tau_YHR106W_YDR353W_PrintScreen.txt