#!/bin/bash
cd YHR106W_YDR353W
/Library/Frameworks/Python.framework/Versions/7.3/bin/python Rooted_HKY_Free_Tau_YHR106W_YDR353W.py > Rooted_HKY_Free_Tau_YHR106W_YDR353W_PrintScreen.txt