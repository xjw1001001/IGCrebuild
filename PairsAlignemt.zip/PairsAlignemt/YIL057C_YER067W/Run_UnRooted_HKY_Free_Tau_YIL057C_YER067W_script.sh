#!/bin/bash
cd YIL057C_YER067W
/Library/Frameworks/Python.framework/Versions/7.3/bin/python UnRooted_HKY_Free_Tau_YIL057C_YER067W.py > UnRooted_HKY_Free_Tau_YIL057C_YER067W_PrintScreen.txt