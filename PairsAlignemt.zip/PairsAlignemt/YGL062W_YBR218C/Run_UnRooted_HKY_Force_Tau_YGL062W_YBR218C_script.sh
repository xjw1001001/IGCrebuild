#!/bin/bash
cd YGL062W_YBR218C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python UnRooted_HKY_Force_Tau_YGL062W_YBR218C.py > UnRooted_HKY_Force_Tau_YGL062W_YBR218C_PrintScreen.txt