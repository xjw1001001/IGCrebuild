#!/bin/bash
cd YBL087C_YER117W
/Library/Frameworks/Python.framework/Versions/7.3/bin/python UnRooted_HKY_Free_Tau_YBL087C_YER117W.py > UnRooted_HKY_Free_Tau_YBL087C_YER117W_PrintScreen.txt