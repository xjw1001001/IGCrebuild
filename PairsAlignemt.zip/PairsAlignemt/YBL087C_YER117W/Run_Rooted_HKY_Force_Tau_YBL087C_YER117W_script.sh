#!/bin/bash
cd YBL087C_YER117W
/Library/Frameworks/Python.framework/Versions/7.3/bin/python Rooted_HKY_Force_Tau_YBL087C_YER117W.py > Rooted_HKY_Force_Tau_YBL087C_YER117W_PrintScreen.txt