#!/bin/bash
cd YGR043C_YLR354C
/Library/Frameworks/Python.framework/Versions/7.3/bin/python UnRooted_HKY_Force_Tau_YGR043C_YLR354C.py > UnRooted_HKY_Force_Tau_YGR043C_YLR354C_PrintScreen.txt